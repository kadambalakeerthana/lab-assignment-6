package com.demo;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.entities.Student;
import com.demo.entities.Course;
import com.demo.repo.StudentRepo;
import com.demo.repo.CourseRepo;

@SpringBootApplication
public class JpaManyToManyApplication implements CommandLineRunner{
	
@Autowired
private StudentRepo studRepo;
@Autowired
private CourseRepo courseRepo;

	public static void main(String[] args) {
		SpringApplication.run(JpaManyToManyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		Student stud1 = new Student("ekta", 878732536);
		Student stud2 = new Student("ravi", 452735360);
		Student stud3 = new Student("raju", 342637432);
		
		Student stud4 = new Student("riya",452791487);
		Student stud5 = new Student("vikas", 452748271);
		Student stud6 = new Student("raj", 562844832);
		
		Course course1 = new Course("java" );
		Course course2 = new Course("dbms" );
		
		
		course1.getStudents().add(stud1);
		course1.getStudents().add(stud2);
		course1.getStudents().add(stud3);
		
		course2.getStudents().add(stud4);
		course2.getStudents().add(stud5);
		course2.getStudents().add(stud6);
		
		stud1.getCourses().add(course1);
		stud2.getCourses().add(course1);
		stud3.getCourses().add(course1);
		
		stud4.getCourses().add(course2);
		stud5.getCourses().add(course2);
		stud6.getCourses().add(course2);
		
		courseRepo.save(course1);
		courseRepo.save(course2);
		
		studRepo.save(stud1);
		studRepo.save(stud2);
		studRepo.save(stud3);

		studRepo.save(stud4);
		studRepo.save(stud5);
		studRepo.save(stud6);
		
		
		
	}

}
