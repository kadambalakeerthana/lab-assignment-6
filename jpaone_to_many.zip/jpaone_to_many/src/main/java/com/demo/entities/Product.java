package com.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product_table")

public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int pid;
	 private String pname;
	 
	
	 @JoinColumn(name="rid_fk")
	 @ManyToOne
	private Review review;
	
	
	public Product(String pname, Review review) {
		
		this.pname = pname;		
		this.review = review;
	}
	
public Product() {
		
	}
	
		
	 public int getPid() {
			return pid;
		}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Review getReview() {
		return review;
	}
	public void setReview(Review review) {
		this.review = review;
	}
	 
}
