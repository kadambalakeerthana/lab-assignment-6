package com.demo.entities;

import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "review_table")

public class Review {

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int rid;
	private String rev; 
	 
	 @OneToMany(mappedBy="review", cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	
	 private List<Product> products = new ArrayList<>();
	 
	 public Review(String rev) {
			
			this.rev = rev;
		}

		public Review() {
			
		}
	 
	 
	 public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public String getRev() {
		return rev;
	}

	public void setRev(String rev) {
		this.rev = rev;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	
	
}
