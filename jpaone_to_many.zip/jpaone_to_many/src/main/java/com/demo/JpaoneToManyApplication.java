package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.demo.entities.Review;
import com.demo.entities.Product;
import com.demo.repo.ReviewRepo;
import com.demo.repo.ProductRepo;


@SpringBootApplication
public class JpaoneToManyApplication implements CommandLineRunner {

@Autowired
private ProductRepo prodRepo;
@Autowired
private ReviewRepo revRepo;

	public static void main(String[] args) {
		SpringApplication.run(JpaoneToManyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		Review r1 = new Review("good");
		Review r2 = new Review("bad");
		
		Product prod1=new Product("soap",r1); 
		Product prod2=new Product("shampoo",r2);
		Product prod3=new Product("paste",r2);
		
		r1.getProducts().add(prod1);
		r2.getProducts().add(prod2);
		r2.getProducts().add(prod3);
		
		revRepo.save(r1);
		revRepo.save(r2);
		
		
		prodRepo.save(prod1);
		prodRepo.save(prod2);
		prodRepo.save(prod3);
		
		
	}

}
